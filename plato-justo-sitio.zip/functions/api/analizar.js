/**
 * Función de Cloudflare Pages.
 *
 * Solo existe para que, cuando publiques con Cloudflare Pages, la dirección
 * /api/analizar de tu propio sitio responda usando la lógica de worker.js.
 * Si publicas con GitHub Pages, este archivo no se usa: ahí despliegas
 * worker.js por separado como Worker.
 */
import worker from "../../worker.js";

export function onRequest(context) {
  return worker.fetch(context.request, context.env);
}
